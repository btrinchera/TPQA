clc;
clear all;

addpath([fileparts(mfilename('fullpath')) filesep() 'info'])

inf = 'G:\LV_prog\TWM\temp\qwtb_test\session.info';

inf = infoload(inf);

