Note this is modified version of the INFO-STRINGS library!!!

Definitely not compatible with version on the GitHub!!!